<?php
/**
 * Lorem Ipsum Books & Media Store Framework: Registered Users
 *
 * @package	lorem_ipsum_books_media_store
 * @since	lorem_ipsum_books_media_store 1.0
 */

// Disable direct call
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Theme init
if (!function_exists('trx_utils_users_theme_setup')) {
	add_action( 'lorem_ipsum_books_media_store_action_before_init_theme', 'trx_utils_users_theme_setup' );
	function trx_utils_users_theme_setup() {

		if ( is_admin() ) {
			// Add extra fields in the user profile
			add_action( 'show_user_profile',		'trx_utils_add_fields_in_user_profile' );
			add_action( 'edit_user_profile',		'trx_utils_add_fields_in_user_profile' );
	
			// Save / update additional fields from profile
			add_action( 'personal_options_update',	'trx_utils_save_fields_in_user_profile' );
			add_action( 'edit_user_profile_update',	'trx_utils_save_fields_in_user_profile' );
		}

	}
}


// Show additional fields in the user profile
if (!function_exists('trx_utils_add_fields_in_user_profile')) {
	function trx_utils_add_fields_in_user_profile( $user ) { 
	?>
		<h3><?php esc_html_e('User Position', 'trx_utils'); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="user_position"><?php esc_html_e('User position', 'trx_utils'); ?>:</label></th>
				<td><input type="text" name="user_position" id="user_position" size="55" value="<?php echo esc_attr(get_the_author_meta('user_position', $user->ID)); ?>" />
					<span class="description"><?php esc_html_e('Please, enter your position in the company', 'trx_utils'); ?></span>
				</td>
			</tr>
		</table>
	
		<h3><?php esc_html_e('Social links', 'trx_utils'); ?></h3>
		<table class="form-table">
		<?php
		$socials_type = lorem_ipsum_books_media_store_get_theme_setting('socials_type');
		$social_list = lorem_ipsum_books_media_store_get_theme_option('social_icons');
		if (is_array($social_list) && count($social_list) > 0) {
			foreach ($social_list as $soc) {
				if ($socials_type == 'icons') {
					$parts = explode('-', $soc['icon'], 2);
					$sn = isset($parts[1]) ? $parts[1] : $soc['icon'];
				} else {
					$sn = basename($soc['icon']);
					$sn = lorem_ipsum_books_media_store_substr($sn, 0, lorem_ipsum_books_media_store_strrpos($sn, '.'));
					if (($pos=lorem_ipsum_books_media_store_strrpos($sn, '_'))!==false)
						$sn = lorem_ipsum_books_media_store_substr($sn, 0, $pos);
				}
				if (!empty($sn)) {
					?>
					<tr>
						<th><label for="user_<?php echo esc_attr($sn); ?>"><?php lorem_ipsum_books_media_store_show_layout(lorem_ipsum_books_media_store_strtoproper($sn)); ?>:</label></th>
						<td><input type="text" name="user_<?php echo esc_attr($sn); ?>" id="user_<?php echo esc_attr($sn); ?>" size="55" value="<?php echo esc_attr(get_the_author_meta('user_'.($sn), $user->ID)); ?>" />
							<span class="description"><?php echo sprintf(esc_html__('Please, enter your %s link', 'trx_utils'), lorem_ipsum_books_media_store_strtoproper($sn)); ?></span>
						</td>
					</tr>
					<?php
				}
			}
		}
		?>
		</table>
	<?php
	}
}

// Save / update additional fields
if (!function_exists('trx_utils_save_fields_in_user_profile')) {
	function trx_utils_save_fields_in_user_profile( $user_id ) {
		if ( !current_user_can( 'edit_user', $user_id ) )
			return false;

		if (isset($_POST['user_position'])) 
			update_user_meta( $user_id, 'user_position', $_POST['user_position'] );
		
		$socials_type = lorem_ipsum_books_media_store_get_theme_setting('socials_type');
		$social_list = lorem_ipsum_books_media_store_get_theme_option('social_icons');
		if (is_array($social_list) && count($social_list) > 0) {
			foreach ($social_list as $soc) {
				if ($socials_type == 'icons') {
					$parts = explode('-', $soc['icon'], 2);
					$sn = isset($parts[1]) ? $parts[1] : $soc['icon'];
				} else {
					$sn = basename($soc['icon']);
					$sn = lorem_ipsum_books_media_store_substr($sn, 0, lorem_ipsum_books_media_store_strrpos($sn, '.'));
					if (($pos=lorem_ipsum_books_media_store_strrpos($sn, '_'))!==false)
						$sn = lorem_ipsum_books_media_store_substr($sn, 0, $pos);
				}
				if (isset($_POST['user_'.($sn)]))
					update_user_meta( $user_id, 'user_'.($sn), $_POST['user_'.($sn)] );
			}
		}
	}
}
?>