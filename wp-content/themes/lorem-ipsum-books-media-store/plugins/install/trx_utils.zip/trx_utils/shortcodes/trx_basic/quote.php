<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('lorem_ipsum_books_media_store_sc_quote_theme_setup')) {
	add_action( 'lorem_ipsum_books_media_store_action_before_init_theme', 'lorem_ipsum_books_media_store_sc_quote_theme_setup' );
	function lorem_ipsum_books_media_store_sc_quote_theme_setup() {
		add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 		'lorem_ipsum_books_media_store_sc_quote_reg_shortcodes');
		if (function_exists('lorem_ipsum_books_media_store_exists_visual_composer') && lorem_ipsum_books_media_store_exists_visual_composer())
			add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc','lorem_ipsum_books_media_store_sc_quote_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_quote id="unique_id" cite="url" title=""]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/quote]
*/

if (!function_exists('lorem_ipsum_books_media_store_sc_quote')) {	
	function lorem_ipsum_books_media_store_sc_quote($atts, $content=null){	
		if (lorem_ipsum_books_media_store_in_shortcode_blogger()) return '';
		extract(lorem_ipsum_books_media_store_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			"cite" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . lorem_ipsum_books_media_store_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= lorem_ipsum_books_media_store_get_css_dimensions_from_values($width);
		$cite_param = $cite != '' ? ' cite="'.esc_attr($cite).'"' : '';
		$title = $title=='' ? $cite : $title;
		$content = do_shortcode($content);
		if (lorem_ipsum_books_media_store_substr($content, 0, 2)!='<p') $content = '<p>' . ($content) . '</p>';
		$output = '<blockquote' 
			. ($id ? ' id="'.esc_attr($id).'"' : '') . ($cite_param) 
			. ' class="sc_quote'. (!empty($class) ? ' '.esc_attr($class) : '').'"' 
			. (!lorem_ipsum_books_media_store_param_is_off($animation) ? ' data-animation="'.esc_attr(lorem_ipsum_books_media_store_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
			. '>'
				. ($content)
				. ($title == '' ? '' : ('<p class="sc_quote_title">' . ($cite!='' ? '<a href="'.esc_url($cite).'">' : '') . ($title) . ($cite!='' ? '</a>' : '') . '</p>'))
			.'</blockquote>';
		return apply_filters('lorem_ipsum_books_media_store_shortcode_output', $output, 'trx_quote', $atts, $content);
	}
	add_shortcode('trx_quote', 'lorem_ipsum_books_media_store_sc_quote');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_quote_reg_shortcodes' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 'lorem_ipsum_books_media_store_sc_quote_reg_shortcodes');
	function lorem_ipsum_books_media_store_sc_quote_reg_shortcodes() {
	
		lorem_ipsum_books_media_store_sc_map("trx_quote", array(
			"title" => esc_html__("Quote", 'trx_utils'),
			"desc" => wp_kses_data( __("Quote text", 'trx_utils') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"cite" => array(
					"title" => esc_html__("Quote cite", 'trx_utils'),
					"desc" => wp_kses_data( __("URL for quote cite", 'trx_utils') ),
					"value" => "",
					"type" => "text"
				),
				"title" => array(
					"title" => esc_html__("Title (author)", 'trx_utils'),
					"desc" => wp_kses_data( __("Quote title (author name)", 'trx_utils') ),
					"value" => "",
					"type" => "text"
				),
				"_content_" => array(
					"title" => esc_html__("Quote content", 'trx_utils'),
					"desc" => wp_kses_data( __("Quote content", 'trx_utils') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"width" => lorem_ipsum_books_media_store_shortcodes_width(),
				"top" => lorem_ipsum_books_media_store_get_sc_param('top'),
				"bottom" => lorem_ipsum_books_media_store_get_sc_param('bottom'),
				"left" => lorem_ipsum_books_media_store_get_sc_param('left'),
				"right" => lorem_ipsum_books_media_store_get_sc_param('right'),
				"id" => lorem_ipsum_books_media_store_get_sc_param('id'),
				"class" => lorem_ipsum_books_media_store_get_sc_param('class'),
				"animation" => lorem_ipsum_books_media_store_get_sc_param('animation'),
				"css" => lorem_ipsum_books_media_store_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_quote_reg_shortcodes_vc' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc', 'lorem_ipsum_books_media_store_sc_quote_reg_shortcodes_vc');
	function lorem_ipsum_books_media_store_sc_quote_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_quote",
			"name" => esc_html__("Quote", 'trx_utils'),
			"description" => wp_kses_data( __("Quote text", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_quote',
			"class" => "trx_sc_single trx_sc_quote",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "cite",
					"heading" => esc_html__("Quote cite", 'trx_utils'),
					"description" => wp_kses_data( __("URL for the quote cite link", 'trx_utils') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title (author)", 'trx_utils'),
					"description" => wp_kses_data( __("Quote title (author name)", 'trx_utils') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "content",
					"heading" => esc_html__("Quote content", 'trx_utils'),
					"description" => wp_kses_data( __("Quote content", 'trx_utils') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				lorem_ipsum_books_media_store_get_vc_param('id'),
				lorem_ipsum_books_media_store_get_vc_param('class'),
				lorem_ipsum_books_media_store_get_vc_param('animation'),
				lorem_ipsum_books_media_store_get_vc_param('css'),
				lorem_ipsum_books_media_store_vc_width(),
				lorem_ipsum_books_media_store_get_vc_param('margin_top'),
				lorem_ipsum_books_media_store_get_vc_param('margin_bottom'),
				lorem_ipsum_books_media_store_get_vc_param('margin_left'),
				lorem_ipsum_books_media_store_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Quote extends Lorem_Ipsum_Books_Media_Store_VC_ShortCodeSingle {}
	}
}
?>