<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('lorem_ipsum_books_media_store_sc_content_theme_setup')) {
	add_action( 'lorem_ipsum_books_media_store_action_before_init_theme', 'lorem_ipsum_books_media_store_sc_content_theme_setup' );
	function lorem_ipsum_books_media_store_sc_content_theme_setup() {
		add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 		'lorem_ipsum_books_media_store_sc_content_reg_shortcodes');
		if (function_exists('lorem_ipsum_books_media_store_exists_visual_composer') && lorem_ipsum_books_media_store_exists_visual_composer())
			add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc','lorem_ipsum_books_media_store_sc_content_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_content id="unique_id" class="class_name" style="css-styles"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_content]
*/

if (!function_exists('lorem_ipsum_books_media_store_sc_content')) {	
	function lorem_ipsum_books_media_store_sc_content($atts, $content=null){	
		if (lorem_ipsum_books_media_store_in_shortcode_blogger()) return '';
		extract(lorem_ipsum_books_media_store_html_decode(shortcode_atts(array(
			"scheme" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"top" => "",
			"bottom" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . lorem_ipsum_books_media_store_get_css_position_as_classes($top, '', $bottom);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
			. ' class="sc_content content_wrap' 
				. ($scheme && !lorem_ipsum_books_media_store_param_is_off($scheme) && !lorem_ipsum_books_media_store_param_is_inherit($scheme) ? ' scheme_'.esc_attr($scheme) : '') 
				. ($class ? ' '.esc_attr($class) : '') 
				. '"'
			. (!lorem_ipsum_books_media_store_param_is_off($animation) ? ' data-animation="'.esc_attr(lorem_ipsum_books_media_store_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '').'>' 
			. do_shortcode($content) 
			. '</div>';
		return apply_filters('lorem_ipsum_books_media_store_shortcode_output', $output, 'trx_content', $atts, $content);
	}
	add_shortcode('trx_content', 'lorem_ipsum_books_media_store_sc_content');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_content_reg_shortcodes' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 'lorem_ipsum_books_media_store_sc_content_reg_shortcodes');
	function lorem_ipsum_books_media_store_sc_content_reg_shortcodes() {
	
		lorem_ipsum_books_media_store_sc_map("trx_content", array(
			"title" => esc_html__("Content block", 'trx_utils'),
			"desc" => wp_kses_data( __("Container for main content block with desired class and style (use it only on fullscreen pages)", 'trx_utils') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"scheme" => array(
					"title" => esc_html__("Color scheme", 'trx_utils'),
					"desc" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
					"value" => "",
					"type" => "checklist",
					"options" => lorem_ipsum_books_media_store_get_sc_param('schemes')
				),
				"_content_" => array(
					"title" => esc_html__("Container content", 'trx_utils'),
					"desc" => wp_kses_data( __("Content for section container", 'trx_utils') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"top" => lorem_ipsum_books_media_store_get_sc_param('top'),
				"bottom" => lorem_ipsum_books_media_store_get_sc_param('bottom'),
				"id" => lorem_ipsum_books_media_store_get_sc_param('id'),
				"class" => lorem_ipsum_books_media_store_get_sc_param('class'),
				"animation" => lorem_ipsum_books_media_store_get_sc_param('animation'),
				"css" => lorem_ipsum_books_media_store_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_content_reg_shortcodes_vc' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc', 'lorem_ipsum_books_media_store_sc_content_reg_shortcodes_vc');
	function lorem_ipsum_books_media_store_sc_content_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_content",
			"name" => esc_html__("Content block", 'trx_utils'),
			"description" => wp_kses_data( __("Container for main content block (use it only on fullscreen pages)", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_content',
			"class" => "trx_sc_collection trx_sc_content",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "scheme",
					"heading" => esc_html__("Color scheme", 'trx_utils'),
					"description" => wp_kses_data( __("Select color scheme for this block", 'trx_utils') ),
					"group" => esc_html__('Colors and Images', 'trx_utils'),
					"class" => "",
					"value" => array_flip(lorem_ipsum_books_media_store_get_sc_param('schemes')),
					"type" => "dropdown"
				),
				lorem_ipsum_books_media_store_get_vc_param('id'),
				lorem_ipsum_books_media_store_get_vc_param('class'),
				lorem_ipsum_books_media_store_get_vc_param('animation'),
				lorem_ipsum_books_media_store_get_vc_param('css'),
				lorem_ipsum_books_media_store_get_vc_param('margin_top'),
				lorem_ipsum_books_media_store_get_vc_param('margin_bottom')
			)
		) );
		
		class WPBakeryShortCode_Trx_Content extends Lorem_Ipsum_Books_Media_Store_VC_ShortCodeCollection {}
	}
}
?>