<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('lorem_ipsum_books_media_store_sc_emailer_theme_setup')) {
	add_action( 'lorem_ipsum_books_media_store_action_before_init_theme', 'lorem_ipsum_books_media_store_sc_emailer_theme_setup' );
	function lorem_ipsum_books_media_store_sc_emailer_theme_setup() {
		add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 		'lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes');
		if (function_exists('lorem_ipsum_books_media_store_exists_visual_composer') && lorem_ipsum_books_media_store_exists_visual_composer())
			add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc','lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

//[trx_emailer group=""]

if (!function_exists('lorem_ipsum_books_media_store_sc_emailer')) {	
	function lorem_ipsum_books_media_store_sc_emailer($atts, $content = null) {
		if (lorem_ipsum_books_media_store_in_shortcode_blogger()) return '';
		extract(lorem_ipsum_books_media_store_html_decode(shortcode_atts(array(
			// Individual params
			"group" => "",
			"open" => "yes",
			"align" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => "",
			"width" => "",
			"height" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . lorem_ipsum_books_media_store_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= lorem_ipsum_books_media_store_get_css_dimensions_from_values($width, $height);
        static $cnt = 0;
        $cnt++;
        $privacy = trx_utils_get_privacy_text();
		// Load core messages
		lorem_ipsum_books_media_store_enqueue_messages();
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
					. ' class="sc_emailer' . ($align && $align!='none' ? ' align' . esc_attr($align) : '') . (lorem_ipsum_books_media_store_param_is_on($open) ? ' sc_emailer_opened' : '') . (!empty($class) ? ' '.esc_attr($class) : '') . '"' 
					. ($css ? ' style="'.esc_attr($css).'"' : '') 
					. (!lorem_ipsum_books_media_store_param_is_off($animation) ? ' data-animation="'.esc_attr(lorem_ipsum_books_media_store_get_animation_classes($animation)).'"' : '')
					. '>'
				. '<form class="sc_emailer_form">'
                . '<div class="sc_emailer_input_wrap">'
				. '<input type="text" class="sc_emailer_input" name="email" value="" placeholder="'.esc_attr__('E-mail *', 'trx_utils').'">'
				. '<button class="sc_emailer_button icon-iconmonstr-email-2" ' . (!empty($privacy) ? ' disabled="disabled"' : '') . ' title="'.esc_attr__('Submit', 'trx_utils').'" data-group="'.esc_attr($group ? $group : esc_html__('E-mailer subscription', 'trx_utils')).'"></button>'
                . '</div>'
                . ((!empty($privacy)) ? '<div class="sc_form_field sc_form_field_checkbox">
                  <input type="checkbox" id="i_agree_privacy_policy_sc_form_' . esc_attr($cnt) . '" name="i_agree_privacy_policy" class="sc_form_privacy_checkbox" value="1">
                  <label for="i_agree_privacy_policy_sc_form_' . esc_attr($cnt) . '">' . $privacy . '</label></div>' : '')

            . '</form>'
                . trim(lorem_ipsum_books_media_store_sc_socials(array('size'=>"medium")))
			. '</div>';
		return apply_filters('lorem_ipsum_books_media_store_shortcode_output', $output, 'trx_emailer', $atts, $content);
	}
	add_shortcode("trx_emailer", "lorem_ipsum_books_media_store_sc_emailer");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 'lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes');
	function lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes() {
	
		lorem_ipsum_books_media_store_sc_map("trx_emailer", array(
			"title" => esc_html__("E-mail collector", 'trx_utils'),
			"desc" => wp_kses_data( __("Collect the e-mail address into specified group", 'trx_utils') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"group" => array(
					"title" => esc_html__("Group", 'trx_utils'),
					"desc" => wp_kses_data( __("The name of group to collect e-mail address", 'trx_utils') ),
					"value" => "",
					"type" => "text"
				),
				"open" => array(
					"title" => esc_html__("Open", 'trx_utils'),
					"desc" => wp_kses_data( __("Initially open the input field on show object", 'trx_utils') ),
					"divider" => true,
					"value" => "yes",
					"type" => "switch",
					"options" => lorem_ipsum_books_media_store_get_sc_param('yes_no')
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'trx_utils'),
					"desc" => wp_kses_data( __("Align object to left, center or right", 'trx_utils') ),
					"divider" => true,
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => lorem_ipsum_books_media_store_get_sc_param('align')
				), 
				"width" => lorem_ipsum_books_media_store_shortcodes_width(),
				"height" => lorem_ipsum_books_media_store_shortcodes_height(),
				"top" => lorem_ipsum_books_media_store_get_sc_param('top'),
				"bottom" => lorem_ipsum_books_media_store_get_sc_param('bottom'),
				"left" => lorem_ipsum_books_media_store_get_sc_param('left'),
				"right" => lorem_ipsum_books_media_store_get_sc_param('right'),
				"id" => lorem_ipsum_books_media_store_get_sc_param('id'),
				"class" => lorem_ipsum_books_media_store_get_sc_param('class'),
				"animation" => lorem_ipsum_books_media_store_get_sc_param('animation'),
				"css" => lorem_ipsum_books_media_store_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes_vc' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc', 'lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes_vc');
	function lorem_ipsum_books_media_store_sc_emailer_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_emailer",
			"name" => esc_html__("E-mail collector", 'trx_utils'),
			"description" => wp_kses_data( __("Collect e-mails into specified group", 'trx_utils') ),
			"category" => esc_html__('Content', 'trx_utils'),
			'icon' => 'icon_trx_emailer',
			"class" => "trx_sc_single trx_sc_emailer",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "group",
					"heading" => esc_html__("Group", 'trx_utils'),
					"description" => wp_kses_data( __("The name of group to collect e-mail address", 'trx_utils') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "open",
					"heading" => esc_html__("Opened", 'trx_utils'),
					"description" => wp_kses_data( __("Initially open the input field on show object", 'trx_utils') ),
					"class" => "",
					"value" => array(esc_html__('Initially opened', 'trx_utils') => 'yes'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'trx_utils'),
					"description" => wp_kses_data( __("Align field to left, center or right", 'trx_utils') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(lorem_ipsum_books_media_store_get_sc_param('align')),
					"type" => "dropdown"
				),
				lorem_ipsum_books_media_store_get_vc_param('id'),
				lorem_ipsum_books_media_store_get_vc_param('class'),
				lorem_ipsum_books_media_store_get_vc_param('animation'),
				lorem_ipsum_books_media_store_get_vc_param('css'),
				lorem_ipsum_books_media_store_vc_width(),
				lorem_ipsum_books_media_store_vc_height(),
				lorem_ipsum_books_media_store_get_vc_param('margin_top'),
				lorem_ipsum_books_media_store_get_vc_param('margin_bottom'),
				lorem_ipsum_books_media_store_get_vc_param('margin_left'),
				lorem_ipsum_books_media_store_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Emailer extends Lorem_Ipsum_Books_Media_Store_VC_ShortCodeSingle {}
	}
}
?>