<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('lorem_ipsum_books_media_store_sc_gap_theme_setup')) {
	add_action( 'lorem_ipsum_books_media_store_action_before_init_theme', 'lorem_ipsum_books_media_store_sc_gap_theme_setup' );
	function lorem_ipsum_books_media_store_sc_gap_theme_setup() {
		add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 		'lorem_ipsum_books_media_store_sc_gap_reg_shortcodes');
		if (function_exists('lorem_ipsum_books_media_store_exists_visual_composer') && lorem_ipsum_books_media_store_exists_visual_composer())
			add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc','lorem_ipsum_books_media_store_sc_gap_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

//[trx_gap]Fullwidth content[/trx_gap]

if (!function_exists('lorem_ipsum_books_media_store_sc_gap')) {	
	function lorem_ipsum_books_media_store_sc_gap($atts, $content = null) {
		if (lorem_ipsum_books_media_store_in_shortcode_blogger()) return '';
		$output = lorem_ipsum_books_media_store_gap_start() . do_shortcode($content) . lorem_ipsum_books_media_store_gap_end();
		return apply_filters('lorem_ipsum_books_media_store_shortcode_output', $output, 'trx_gap', $atts, $content);
	}
	add_shortcode("trx_gap", "lorem_ipsum_books_media_store_sc_gap");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_gap_reg_shortcodes' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list', 'lorem_ipsum_books_media_store_sc_gap_reg_shortcodes');
	function lorem_ipsum_books_media_store_sc_gap_reg_shortcodes() {
	
		lorem_ipsum_books_media_store_sc_map("trx_gap", array(
			"title" => esc_html__("Gap", 'trx_utils'),
			"desc" => wp_kses_data( __("Insert gap (fullwidth area) in the post content. Attention! Use the gap only in the posts (pages) without left or right sidebar", 'trx_utils') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Gap content", 'trx_utils'),
					"desc" => wp_kses_data( __("Gap inner content", 'trx_utils') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				)
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'lorem_ipsum_books_media_store_sc_gap_reg_shortcodes_vc' ) ) {
	//add_action('lorem_ipsum_books_media_store_action_shortcodes_list_vc', 'lorem_ipsum_books_media_store_sc_gap_reg_shortcodes_vc');
	function lorem_ipsum_books_media_store_sc_gap_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_gap",
			"name" => esc_html__("Gap", 'trx_utils'),
			"description" => wp_kses_data( __("Insert gap (fullwidth area) in the post content", 'trx_utils') ),
			"category" => esc_html__('Structure', 'trx_utils'),
			'icon' => 'icon_trx_gap',
			"class" => "trx_sc_collection trx_sc_gap",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => false,
			"params" => array(
			)
		) );
		
		class WPBakeryShortCode_Trx_Gap extends Lorem_Ipsum_Books_Media_Store_VC_ShortCodeCollection {}
	}
}
?>